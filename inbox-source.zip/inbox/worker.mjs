const origin = "https://poorvi-03.github.io";
function response(body, status = 200) {
  return new Response(body == null ? null : JSON.stringify(body), {status, headers:{
    "Content-Type":"application/json", "Cache-Control":"no-store",
    "Access-Control-Allow-Origin":origin,
    "Access-Control-Allow-Headers":"Authorization, Content-Type",
    "Access-Control-Allow-Methods":"GET, POST, OPTIONS"
  }});
}
async function authorized(request, secret) {
  const auth = request.headers.get("Authorization") || "";
  if (!secret || auth.length > 256) return false;
  const bytes = new TextEncoder();
  const actual = await crypto.subtle.digest("SHA-256",bytes.encode(auth));
  const expected = await crypto.subtle.digest("SHA-256",bytes.encode("Bearer " + secret));
  return crypto.subtle.timingSafeEqual(actual, expected);
}
const moves = ["Company careers site", "LinkedIn Apply", "LinkedIn referral", "Email", "Verify eligibility"];
const isUrl = value => {
  try { return ["https:","http:"].includes(new URL(value).protocol); }
  catch { return false; }
};
function valid(job) {
  if (!job || typeof job !== "object" || Object.values(job).some(value => typeof value !== "string" && typeof value !== "number")) return false;
  return Number.isInteger(Number(job.rank)) && Number(job.rank) >= 1 && Number(job.rank) <= 20 &&
    job.title?.trim?.() && job.company?.trim?.() && isUrl(job.source_url) && job.posting_date?.trim?.() &&
    moves.includes(job.best_move) && (job.best_move !== "Company careers site" || isUrl(job.official_url)) &&
    (job.best_move !== "LinkedIn referral" || isUrl(job.referral_url)) &&
    (job.best_move !== "Email" || (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(job.email) && isUrl(job.email_source_url)));
}
export default {
  async fetch(request, env) {
    if (new URL(request.url).pathname !== "/shortlist") return response({error:"Unknown route"},404);
    if (request.method === "OPTIONS") return response(null,204);
    if (!["GET","POST"].includes(request.method)) return response({error:"Unsupported method"},405);
    if (!await authorized(request, request.method === "GET" ? env.READ_KEY : env.WRITE_KEY)) return response({error:"Unauthorized"},401);
    if (request.method === "GET") {
      const row = await env.DB.prepare("SELECT payload FROM latest WHERE id = 1").first();
      return row ? response(JSON.parse(row.payload)) : response(null,204);
    }
    if (Number(request.headers.get("Content-Length")) > 100000) return response({error:"Batch too big"},413);
    let data;
    try {
      const json = await request.text();
      if (json.length > 100000) return response({error:"Batch too big"},413);
      data = JSON.parse(json);
    } catch { return response({error:"Invalid JSON"},400); }
    const today = new Date().toLocaleDateString("sv-SE",{timeZone:"Asia/Kolkata"});
    if (data?.batch_date !== today || !Array.isArray(data.jobs) || data.jobs.length < 1 || data.jobs.length > 20 ||
        !data.jobs.every(valid) || new Set(data.jobs.map(job => Number(job.rank))).size !== data.jobs.length) {
      return response({error:"Send today's India date and 1–20 valid jobs with distinct ranks"},400);
    }
    const stored = {batch_date:data.batch_date, jobs:data.jobs};
    await env.DB.prepare("INSERT INTO latest(id, payload) VALUES(1, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload")
      .bind(JSON.stringify(stored)).run();
    return response({delivered:true, batch_date:data.batch_date, count:data.jobs.length});
  }
};
